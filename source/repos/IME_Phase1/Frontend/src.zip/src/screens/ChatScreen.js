import GradientHeader from '../components/GradientHeader';
import { COLORS } from './theme';
import React, { useState, useEffect, useRef, useCallback } from 'react';
import { View, Text, FlatList, TextInput, TouchableOpacity, KeyboardAvoidingView, Platform, ActivityIndicator, StatusBar } from 'react-native';
import { useAuth } from '../context/AuthContext';
import { chatService } from '../services/chatService';
import { ChatScreenStyles as styles } from './screenStyles';
import { SafeAreaView, useSafeAreaInsets } from 'react-native-safe-area-context';

const POLL_INTERVAL_MS = 3000;

const ChatScreen = ({ navigation, route }) => {
  const {
    conversationId:   initialConversationId,
    otherMemberName,
    otherMemberEmail,
    otherMemberId,
  } = route.params || {};
  const { user } = useAuth();

  // ✅ Hooks must be called INSIDE the component body, never at module top-level.
  const insets = useSafeAreaInsets();
  const bottomPad = Math.max(insets.bottom, 8) + 8;

  // Local, mutable copy — becomes a real id once the conversation is created
  // (brand-new chats start with conversationId === null).
  const [conversationId, setConversationId] = useState(initialConversationId || null);

  const [messages,    setMessages]    = useState([]);
  const [inputText,   setInputText]   = useState('');
  const [sending,     setSending]     = useState(false);
  // Only show the spinner if we actually have a conversation to fetch.
  const [initialLoad, setInitialLoad] = useState(!!initialConversationId);

  const flatListRef  = useRef(null);
  const pollTimerRef = useRef(null);
  const latestIdRef  = useRef(0);
  const isMounted    = useRef(true);

  useEffect(() => {
    isMounted.current = true;

    // Brand-new chat — nothing exists yet, don't call the API.
    if (!conversationId) {
      setMessages([]);
      setInitialLoad(false);
      return () => { isMounted.current = false; };
    }

    loadMessages(true);
    pollTimerRef.current = setInterval(pollNewMessages, POLL_INTERVAL_MS);

    return () => {
      isMounted.current = false;
      clearInterval(pollTimerRef.current);
    };
  }, [conversationId]);

  const loadMessages = async (isInitial = false) => {
    if (!conversationId) return; // guard: no conversation to fetch yet
    try {
      const res = await chatService.getMessages(conversationId, 1, 100);
      if (!isMounted.current) return;
      if (res.success && Array.isArray(res.data)) {
        setMessages(res.data);
        if (res.data.length > 0) {
          latestIdRef.current = res.data[res.data.length - 1].messageId;
        }
        if (isInitial) {
          setTimeout(() => scrollToBottom(), 100);
        }
      }
    } finally {
      if (isMounted.current) setInitialLoad(false);
    }
  };

  const pollNewMessages = async () => {
    if (!conversationId) return; // guard: no conversation to poll yet
    try {
      const res = await chatService.getMessages(conversationId, 1, 100);
      if (!isMounted.current) return;
      if (res.success && Array.isArray(res.data)) {
        const newMsgs = res.data.filter(m => m.messageId > latestIdRef.current);
        if (newMsgs.length > 0) {
          setMessages(res.data);
          latestIdRef.current = res.data[res.data.length - 1].messageId;
          scrollToBottom();
        }
      }
    } catch (_) { /* silent */ }
  };

  const scrollToBottom = () => {
    flatListRef.current?.scrollToEnd({ animated: true });
  };

  const handleSend = async () => {
    debugger;
  const text = inputText.trim();
  if (!text || sending) return;

  setInputText('');
  setSending(true);

  const clientTime = new Date().toISOString();

  // Optimistic update with client local time
  const tempId = Date.now() * -1;
  const optimistic = {
    messageId:      tempId,
    conversationId,
    senderId:       user?.memberId ?? 0,
    senderName:     user?.fullName ?? 'Me',
    messageText:    text,
    sentDate:       clientTime,
    isRead:         false,
    isOwn:          true,
  };
  setMessages(prev => [...prev, optimistic]);
  setTimeout(() => scrollToBottom(), 50);

  try {
    debugger;
    let activeConversationId = conversationId;

    // First message of a brand-new chat -> get-or-create the conversation now.
    if (!activeConversationId) {
      if (!otherMemberId) {
        throw new Error('Missing otherMemberId — cannot start conversation');
      }
      const createRes = await chatService.getOrCreateConversation(otherMemberId);
      if (!createRes.success || !createRes.data?.conversationId) {
        throw new Error('Could not start conversation');
      }
      activeConversationId = createRes.data.conversationId;
      setConversationId(activeConversationId);
    }

    const res = await chatService.sendMessage(activeConversationId, text, clientTime);
    if (res.success) {
      // Replace optimistic message with real one
      setMessages(prev =>
        prev.map(m =>
          m.messageId === tempId
            ? { ...m, messageId: res.data?.messageId ?? tempId, sentDate: res.data?.sentDate ?? m.sentDate }
            : m
        )
      );
      latestIdRef.current = res.data?.messageId ?? latestIdRef.current;
    } else {
      // Remove failed optimistic message
      setMessages(prev => prev.filter(m => m.messageId !== tempId));
    }
  } catch (_) {
    setMessages(prev => prev.filter(m => m.messageId !== tempId));
  } finally {
    setSending(false);
  }
};

  const formatTime = (dateStr) => {
    if (!dateStr) return '';
    const d = new Date(dateStr + (dateStr.endsWith('Z') ? '' : 'Z'));
    return d.toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit', hour12: true });
  };

  const renderMessage = useCallback(({ item }) => {
    const isOwn    = item.isOwn;
    const timeText = formatTime(item.sentDate);

    return (
      <View style={[styles.msgRow, isOwn ? styles.msgRowOwn : styles.msgRowOther]}>
        <View style={[styles.bubble, isOwn ? styles.bubbleOwn : styles.bubbleOther]}>
          <Text style={[styles.bubbleText, isOwn ? styles.bubbleTextOwn : styles.bubbleTextOther]}>
            {item.messageText}
          </Text>
          <Text style={[styles.timeText, isOwn ? styles.timeOwn : styles.timeOther]}>
            {timeText}
          </Text>
        </View>
      </View>
    );
  }, []);

  return (
    // SafeAreaView (default edges) — matches the working LawBotScreen/Chat.js pattern.
    <SafeAreaView style={styles.container} edges={['left', 'right', 'bottom']}>
      <StatusBar backgroundColor={COLORS.headerStart} barStyle="light-content" />

      {/* Header */}
      <GradientHeader style={styles.header}>
        <TouchableOpacity onPress={() => navigation.goBack()} style={styles.backBtn}>
          <Text style={styles.backIcon}>←</Text>
        </TouchableOpacity>
        <View style={styles.headerAvatar}>
          <Text style={styles.headerAvatarLetter}>
            {(otherMemberName || 'M').charAt(0).toUpperCase()}
          </Text>
        </View>
        <View style={styles.headerInfo}>
          <Text style={styles.headerName}>{otherMemberName || 'Chat'}</Text>
        </View>
      </GradientHeader>

      {/* Messages + input bar share one KeyboardAvoidingView so they move
          together above the keyboard, same as LawBotScreen/Chat.js. */}
      <KeyboardAvoidingView
        style={{ flex: 1 }}
        behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
      >
        {initialLoad ? (
          <View style={styles.centerBox}>
            <ActivityIndicator size="large" color={COLORS.dark} />
          </View>
        ) : (
          <FlatList
            ref={flatListRef}
            data={messages}
            keyExtractor={(item) => String(item.messageId)}
            renderItem={renderMessage}
            contentContainerStyle={styles.messageList}
            showsVerticalScrollIndicator={false}
            onContentSizeChange={scrollToBottom}
            style={{ flex: 1 }}
            ListEmptyComponent={
              <View style={styles.emptyWrap}>
                <Text style={styles.emptyText}>
                  {conversationId ? 'Say hello! 👋' : 'Say hello to start the conversation'}
                </Text>
              </View>
            }
          />
        )}

        {/* Input bar */}
        <View style={[styles.inputBar, { paddingBottom: bottomPad }]}>
          <TextInput
            style={styles.textInput}
            value={inputText}
            onChangeText={setInputText}
            placeholder="Type a message…"
            placeholderTextColor="#aaa"
            multiline
            maxLength={2000}
            returnKeyType="default"
            autoCorrect={false}
            autoComplete="off"
            spellCheck={false}
          />
          <TouchableOpacity
            style={[styles.sendBtn, (!inputText.trim() || sending) && styles.sendBtnDisabled]}
            onPress={handleSend}
            disabled={!inputText.trim() || sending}
            activeOpacity={0.8}
          >
            {sending
              ? <ActivityIndicator size="small" color={COLORS.white} />
              : <Text style={styles.sendIcon}>➤</Text>
            }
          </TouchableOpacity>
        </View>
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
};

export default ChatScreen;