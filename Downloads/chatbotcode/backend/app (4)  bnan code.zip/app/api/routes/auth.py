import time
from typing import Annotated
 
from app.api.deps import get_analytics_db, get_current_user
from app.schemas.user import User
from fastapi import APIRouter, Depends
from motor.motor_asyncio import AsyncIOMotorDatabase
 
router = APIRouter(prefix="/auth", tags=["Authentication"])
 
@router.get("/secure")
async def secure_data(
    db_analytics: Annotated[AsyncIOMotorDatabase, Depends(get_analytics_db)],
    user: Annotated[User, Depends(get_current_user)],
):
    event_data = {
        "type": "login_success",
        "user": {
            "id": str(user.id),
            "email": user.email,
            "name": user.name,
            "roles": user.roles,
        },
        "timestamp": int(time.time()),
    }
 
    await db_analytics["auth_events"].insert_one(event_data)
    return {"message": "SSO Success!", "user": user}