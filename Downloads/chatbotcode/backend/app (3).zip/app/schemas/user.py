from enum import Enum
from typing import List, Optional
from bson import ObjectId
from pydantic import BaseModel, EmailStr, Field, field_validator

class Role(str, Enum):
    admin = "admin"
    user = "user"

class UserBase(BaseModel):
    email: Optional[EmailStr] = None
    is_active: bool = True
    roles: List[Role] = Field(default_factory=lambda: [Role.user])
    name: Optional[str] = None

class UserCreate(UserBase):
    email: EmailStr

class UserUpdate(UserBase):
    pass

class UserInDBBase(UserBase):
    id: str = Field(..., alias="_id")

    @field_validator("id", mode="before")
    @classmethod
    def convert_id_to_str(cls, v):
        if isinstance(v, ObjectId):
            return str(v)
        return v

    class Config:
        from_attributes = True
        populate_by_name = True
        json_encoders = {ObjectId: str}

class User(UserInDBBase):
    pass

class UserInDB(UserInDBBase):
    pass
