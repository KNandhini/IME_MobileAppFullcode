import traceback
from typing import Annotated

import httpx
from app.api.deps import get_httpx_client, get_users_db
from app.core.config import settings
from app.schemas.user import User
from fastapi import APIRouter, Depends, HTTPException
from fastapi.security import HTTPAuthorizationCredentials, HTTPBearer
from jose import JWTError, jwk, jwt
from motor.motor_asyncio import AsyncIOMotorDatabase

from app.services.users import create_user_from_token, get_user_by_email

router = APIRouter(tags=["Authentication"])
security = HTTPBearer()


# Configuration
JWKS_URL = f"https://login.microsoftonline.com/{settings.TENANT_ID}/discovery/v2.0/keys"
VALID_ISSUERS = [
    f"https://sts.windows.net/{settings.TENANT_ID}/",
    f"https://login.microsoftonline.com/{settings.TENANT_ID}/v2.0",
]


async def verify_token(
    token: str, request_client: httpx.AsyncClient, db: AsyncIOMotorDatabase
) -> User:
    try:
        headers = jwt.get_unverified_header(token)
        kid = headers.get("kid")
        response = await request_client.get(JWKS_URL)
        jwks = response.json()["keys"]
        key_data = next((k for k in jwks if k["kid"] == kid), None)
        if not key_data:
            raise Exception("Public key not found in JWKS")

        key_data["alg"] = key_data.get("alg", "RS256")
        key = jwk.construct(key_data)

        claims = jwt.decode(
            token,
            key,
            algorithms=["RS256"],
            audience=settings.AUDIENCE,
            issuer=VALID_ISSUERS,
        )

        user_email = claims.get("upn")
        user = await get_user_by_email(db, email=user_email)
        if user:
            return user

        user_data = {
            "id": claims.get("oid"),
            "name": claims.get("name"),
            "email": user_email,
            "roles": [role.lower() for role in claims.get("roles", [])],
        }
        return await create_user_from_token(db, user_data=user_data)

    # to be catched by endpoint
    except JWTError as e:
        return f"JWT error: {str(e)}"
    except Exception as ex:
        traceback.print_exception(ex)
        return f"General error: {str(ex)}"


@router.get("/me", response_model=User)
async def get_me(
    db: Annotated[AsyncIOMotorDatabase, Depends(get_users_db)],
    request_client: Annotated[httpx.AsyncClient, Depends(get_httpx_client)],
    token: HTTPAuthorizationCredentials = Depends(security),
):
    user = await verify_token(token.credentials, request_client, db)
    if isinstance(user, str):
        raise HTTPException(status_code=401, detail=user)
    return user
